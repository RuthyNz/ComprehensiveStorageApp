﻿namespace ComprehensiveStorageApp.Functions
{
    public class WriteToFile
    {
    }
}
