﻿namespace ComprehensiveStorageApp.Functions
{
    public class QueueTransaction
    {
    }
}
