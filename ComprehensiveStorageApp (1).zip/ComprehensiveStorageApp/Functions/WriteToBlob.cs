﻿namespace ComprehensiveStorageApp.Functions
{
    public class WriteToBlob
    {
    }
}
