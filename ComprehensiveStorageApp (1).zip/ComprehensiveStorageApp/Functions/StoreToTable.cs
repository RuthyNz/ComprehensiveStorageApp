﻿namespace ComprehensiveStorageApp.Functions
{
    public class StoreToTable
    {
    }
}
