﻿namespace ComprehensiveStorageApp
{
    namespace ComprehensiveStorageApp
    {
        public class AppSettings
        {
            public string StorageConnectionString { get; set; }
        }
    }
}
